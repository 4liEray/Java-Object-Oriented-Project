package Interfaces;

public interface BilSupInterface {
public abstract void addBenefit();
public abstract void addTax();
}
